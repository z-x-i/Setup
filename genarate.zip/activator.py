# ============================================================
# FREE FIRE GUEST ACTIVATOR - JSON PATH SYSTEM
# ============================================================
# Simple: Enter JSON path -> Activate All Accounts
# ============================================================

import asyncio
import aiohttp
import ssl
import json
import os
import sys
import random
import time
import base64
import binascii
import hashlib
from datetime import datetime
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

# ============================================================
# COLORS
# ============================================================

class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    RESET = '\033[0m'

# ============================================================
# BANNER
# ============================================================

def show_banner():
    c = Colors
    print(f"""
{c.CYAN}{'='*60}{c.RESET}
{c.BOLD}{c.PURPLE}    ███████╗████████╗ █████╗ ██████╗ {c.RESET}
{c.BOLD}{c.PURPLE}    ██╔════╝╚══██╔══╝██╔══██╗██╔══██╗{c.RESET}
{c.BOLD}{c.PURPLE}    ███████╗   ██║   ███████║██████╔╝{c.RESET}
{c.BOLD}{c.PURPLE}    ╚════██║   ██║   ██╔══██║██╔══██╗{c.RESET}
{c.BOLD}{c.PURPLE}    ███████║   ██║   ██║  ██║██║  ██║{c.RESET}
{c.BOLD}{c.PURPLE}    ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝{c.RESET}
{c.CYAN}{'='*60}{c.RESET}
{c.BOLD}{c.GREEN}       🔥 FREE FIRE GUEST ACTIVATOR v4.1 🔥{c.RESET}
{c.BOLD}{c.YELLOW}       ⚡ High Speed Major Login Activator ⚡{c.RESET}
{c.CYAN}{'='*60}{c.RESET}
{c.BOLD}{c.PURPLE}       ⭐⭐  STAR  ⭐⭐{c.RESET}
{c.DIM}       Created by: @STAR_RDP | Channel: @STAR_METHODE{c.RESET}
{c.CYAN}{'='*60}{c.RESET}
    """)

# ============================================================
# CONFIG
# ============================================================

CONFIG = {
    "MAX_CONCURRENT": 20,  # High thread support
    "RETRY_COUNT": 3,
    "RETRY_DELAY": 1
}

# ============================================================
# CONSTANTS
# ============================================================

HEADERS = {
    "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 13; SHADOW_X Build/TP1A.220624.014)",
    "Connection": "Keep-Alive",
    "Accept-Encoding": "gzip",
    "Content-Type": "application/x-www-form-urlencoded",
    "X-Unity-Version": "2018.4.11f1",
    "X-GA": "v1 1",
    "ReleaseVersion": "OB54"
}

AES_KEY = b'Yg&tc%DEuh6%Zc^8'
AES_IV = b'6oyZDr22E3ychjM%'

# ============================================================
# PB2 FOLDER SUPPORT
# ============================================================

USE_PB2 = False

try:
    pb2_paths = [
        os.path.join(os.path.dirname(__file__), 'Pb2'),
        os.path.join(os.getcwd(), 'Pb2'),
    ]
    
    pb2_found = None
    for path in pb2_paths:
        if os.path.exists(path):
            pb2_found = path
            break
    
    if pb2_found:
        sys.path.insert(0, pb2_found)
    
    from Pb2 import MajoRLoGinrEs_pb2
    from Pb2 import PorTs_pb2
    from Pb2 import MajoRLoGinrEq_pb2
    
    USE_PB2 = True
    print(f"{Colors.GREEN}✅ Pb2 loaded successfully{Colors.RESET}")
except ImportError:
    print(f"{Colors.YELLOW}⚠️ Pb2 not found, using fallback{Colors.RESET}")
    USE_PB2 = False

# ============================================================
# PROTOBUF FUNCTIONS
# ============================================================

def build_major_login_proto(open_id, access_token, region="auto"):
    """Build major login protobuf"""
    
    if USE_PB2:
        try:
            major_login = MajoRLoGinrEq_pb2.MajorLogin()
            
            major_login.event_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            major_login.game_name = "free fire"
            major_login.platform_id = 1
            major_login.client_version = "1.126.9"
            major_login.system_software = "Android OS 13 / API-33 (TP1A.220905.001/R.206769c-2)"
            major_login.system_hardware = "Handheld"
            major_login.telecom_operator = "45403"
            major_login.network_type = "WIFI"
            major_login.screen_width = 1280
            major_login.screen_height = 720
            major_login.screen_dpi = "320"
            major_login.processor_details = "ARM64 FP ASIMD AES | 2352 | 8"
            major_login.memory = 128
            major_login.gpu_renderer = "Mali-G610"
            major_login.gpu_version = "OpenGL ES 3.2 v1.g18p0-01eac0.2d5e200a1514bdef1a4909db66e37e28"
            major_login.unique_device_id = f"Google|{random.getrandbits(128):032x}"
            major_login.client_ip = f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
            major_login.language = "en"
            major_login.open_id = open_id
            major_login.open_id_type = "4"
            major_login.device_type = "Handheld"
            major_login.device_model = "OPPO CPH2217"
            
            if region and region != "auto":
                major_login.region = region
            
            major_login.access_token = access_token
            major_login.platform_sdk_id = 1
            major_login.network_operator_a = "45403"
            major_login.network_type_a = "WIFI"
            major_login.client_using_version = "1ac4b80ecf0478a44203bf8fac6120f5"
            major_login.external_storage_total = 20660
            major_login.external_storage_available = 17445
            major_login.internal_storage_total = 2663
            major_login.internal_storage_available = 1500
            major_login.game_disk_storage_available = 17573
            major_login.game_disk_storage_total = 20660
            major_login.external_sdcard_avail_storage = 17573
            major_login.external_sdcard_total_storage = 20660
            major_login.login_by = 3
            major_login.library_path = "/data/app/~~xHaSHUdUBlxvhJaRWh018A==/com.dts.freefireth-4OBn7-sLMoPuswIfmgixhA==/lib/arm64"
            major_login.reg_avatar = 1
            major_login.library_token = f"{hashlib.md5(str(random.random()).encode()).hexdigest()}|/data/app/~~xHaSHUdUBlxvhJaRWh018A==/com.dts.freefireth-4OBn7-sLMoPuswIfmgixhA==/base.apk"
            major_login.channel_type = 6
            major_login.cpu_type = 2
            major_login.cpu_architecture = "64"
            major_login.client_version_code = "2019120816"
            major_login.graphics_api = "OpenGLES2"
            major_login.supported_astc_bitset = 16383
            major_login.login_open_id_type = 4
            major_login.analytics_detail = b"FwQVTgUPX1UaUllDDwcWCRBpWA0FUgsvA1snWlBaO1kFYg=="
            major_login.loading_time = 25777
            major_login.release_channel = "3rd_party"
            major_login.extra_info = "KqsHTz+zAigQ0BOzKhQHN8ae/IefLXcroDjaj4QY+OF71nTuiQh+myDUqCZFPJQ5gyC9LfEeKoon9d461764VIGguRHcIyKfExGAh4bvxFZRgp2X"
            major_login.extra_json = '{"cur_rate":null,"support_etc2":false}'
            major_login.android_engine_init_flag = 110009
            major_login.if_push = 1
            major_login.is_vpn = 1
            major_login.origin_platform_type = "4"
            major_login.primary_platform_type = "4"
            major_login.unknown_bytes102 = b"E1JMTwcJXjA2"
            
            return major_login.SerializeToString()
            
        except Exception as e:
            print(f"{Colors.RED}❌ PB2 error: {e}{Colors.RESET}")
    
    # Fallback
    return build_manual_proto(open_id, access_token, region)

def build_manual_proto(open_id, access_token, region="auto"):
    """Manual protobuf encoding"""
    now = datetime.now()
    event_time = now.strftime("%Y-%m-%d %H:%M:%S")
    device_id = f"Google|{random.getrandbits(128):032x}"
    client_ip = f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}"
    lib_token = f"{hashlib.md5(str(random.random()).encode()).hexdigest()}|/data/app/~~xHaSHUdUBlxvhJaRWh018A==/com.dts.freefireth-4OBn7-sLMoPuswIfmgixhA==/base.apk"
    analytics = b"FwQVTgUPX1UaUllDDwcWCRBpWA0FUgsvA1snWlBaO1kFYg=="
    
    proto_parts = []
    
    proto_parts.append(encode_string(1, event_time))
    proto_parts.append(encode_string(2, "free fire"))
    proto_parts.append(encode_varint(3, 1))
    proto_parts.append(encode_string(4, "1.126.9"))
    proto_parts.append(encode_string(5, "Android OS 13 / API-33 (TP1A.220905.001/R.206769c-2)"))
    proto_parts.append(encode_string(6, "Handheld"))
    proto_parts.append(encode_string(7, "45403"))
    proto_parts.append(encode_string(8, "WIFI"))
    proto_parts.append(encode_varint(9, 1280))
    proto_parts.append(encode_varint(10, 720))
    proto_parts.append(encode_string(11, "320"))
    proto_parts.append(encode_string(12, "ARM64 FP ASIMD AES | 2352 | 8"))
    proto_parts.append(encode_varint(13, 128))
    proto_parts.append(encode_string(14, "Mali-G610"))
    proto_parts.append(encode_string(15, "OpenGL ES 3.2 v1.g18p0-01eac0.2d5e200a1514bdef1a4909db66e37e28"))
    proto_parts.append(encode_string(16, device_id))
    proto_parts.append(encode_string(17, client_ip))
    proto_parts.append(encode_string(18, "en"))
    proto_parts.append(encode_string(19, open_id))
    proto_parts.append(encode_string(20, "4"))
    proto_parts.append(encode_string(21, "Handheld"))
    proto_parts.append(encode_string(22, "OPPO CPH2217"))
    
    if region and region != "auto":
        proto_parts.append(encode_string(56, region))
    
    mem_avail = encode_varint(1, 55) + encode_varint(2, 81)
    proto_parts.append(encode_bytes(23, mem_avail))
    proto_parts.append(encode_string(24, access_token))
    proto_parts.append(encode_varint(25, 1))
    proto_parts.append(encode_string(26, "45403"))
    proto_parts.append(encode_string(27, "WIFI"))
    proto_parts.append(encode_string(28, "1ac4b80ecf0478a44203bf8fac6120f5"))
    proto_parts.append(encode_varint(29, 20660))
    proto_parts.append(encode_varint(30, 17445))
    proto_parts.append(encode_varint(31, 2663))
    proto_parts.append(encode_varint(32, 1500))
    proto_parts.append(encode_varint(33, 17573))
    proto_parts.append(encode_varint(34, 20660))
    proto_parts.append(encode_varint(35, 17573))
    proto_parts.append(encode_varint(36, 20660))
    proto_parts.append(encode_varint(37, 3))
    proto_parts.append(encode_string(38, "/data/app/~~xHaSHUdUBlxvhJaRWh018A==/com.dts.freefireth-4OBn7-sLMoPuswIfmgixhA==/lib/arm64"))
    proto_parts.append(encode_varint(39, 1))
    proto_parts.append(encode_string(40, lib_token))
    proto_parts.append(encode_varint(41, 6))
    proto_parts.append(encode_varint(42, 2))
    proto_parts.append(encode_string(43, "64"))
    proto_parts.append(encode_string(44, "2019120816"))
    proto_parts.append(encode_varint(45, 3))
    proto_parts.append(encode_string(46, "OpenGLES2"))
    proto_parts.append(encode_varint(47, 16383))
    proto_parts.append(encode_varint(48, 4))
    proto_parts.append(encode_bytes(49, analytics))
    proto_parts.append(encode_varint(50, 25777))
    proto_parts.append(encode_string(51, "3rd_party"))
    proto_parts.append(encode_string(52, "KqsHTz+zAigQ0BOzKhQHN8ae/IefLXcroDjaj4QY+OF71nTuiQh+myDUqCZFPJQ5gyC9LfEeKoon9d461764VIGguRHcIyKfExGAh4bvxFZRgp2X"))
    proto_parts.append(encode_string(53, '{"cur_rate":null,"support_etc2":false}'))
    proto_parts.append(encode_varint(54, 110009))
    proto_parts.append(encode_varint(55, 1))
    proto_parts.append(encode_varint(56, 1))
    proto_parts.append(encode_string(57, "4"))
    proto_parts.append(encode_string(58, "4"))
    proto_parts.append(encode_bytes(59, b"E1JMTwcJXjA2"))
    
    return b''.join(proto_parts)

def encode_varint(field, value):
    key = (field << 3) | 0
    return encode_zigzag(key) + encode_zigzag(value)

def encode_string(field, value):
    key = (field << 3) | 2
    value_bytes = value.encode('utf-8')
    return encode_zigzag(key) + encode_zigzag(len(value_bytes)) + value_bytes

def encode_bytes(field, value):
    key = (field << 3) | 2
    return encode_zigzag(key) + encode_zigzag(len(value)) + value

def encode_zigzag(value):
    result = []
    while value > 0x7f:
        result.append((value & 0x7f) | 0x80)
        value >>= 7
    result.append(value & 0x7f)
    return bytes(result)

# ============================================================
# ENCRYPTION
# ============================================================

def encrypt_proto(data):
    try:
        cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
        padded = pad(data, AES.block_size)
        encrypted = cipher.encrypt(padded)
        return encrypted
    except Exception as e:
        print(f"{Colors.RED}Encryption error: {e}{Colors.RESET}")
        return None

# ============================================================
# NETWORK FUNCTIONS
# ============================================================

async def get_access_token(uid, password):
    """Get access token"""
    url = "https://100067.connect.garena.com/oauth/guest/token/grant"
    headers = {
        "Host": "100067.connect.garena.com",
        "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 13; SHADOW_X Build/TP1A.220624.014)",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "close"
    }
    data = {
        "uid": uid,
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067"
    }
    
    try:
        timeout = aiohttp.ClientTimeout(total=15)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, headers=headers, data=data, ssl=False) as response:
                if response.status == 200:
                    resp_data = await response.json()
                    open_id = resp_data.get("open_id")
                    access_token = resp_data.get("access_token")
                    if open_id and access_token:
                        return open_id, access_token
                return None, None
    except Exception as e:
        print(f"{Colors.RED}Token error: {e}{Colors.RESET}")
        return None, None

async def major_login(payload):
    """Send major login"""
    url = "https://loginbp.ggblueshark.com/MajorLogin"
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    
    try:
        timeout = aiohttp.ClientTimeout(total=30)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, data=payload, headers=HEADERS, ssl=ssl_context) as response:
                if response.status == 200:
                    return await response.read()
                return None
    except Exception as e:
        print(f"{Colors.RED}Major login error: {e}{Colors.RESET}")
        return None

async def get_login_data(base_url, payload, token):
    """Get login data"""
    url = f"{base_url}/GetLoginData"
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE
    
    headers = HEADERS.copy()
    headers['Authorization'] = f"Bearer {token}"
    
    try:
        timeout = aiohttp.ClientTimeout(total=15)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(url, data=payload, headers=headers, ssl=ssl_context) as response:
                if response.status == 200:
                    return await response.read()
                return None
    except Exception as e:
        print(f"{Colors.RED}GetLoginData error: {e}{Colors.RESET}")
        return None

# ============================================================
# PARSERS
# ============================================================

def parse_major_login_response(data):
    """Parse major login response"""
    try:
        if USE_PB2:
            try:
                response = MajoRLoGinrEs_pb2.MajorLoginRes()
                response.ParseFromString(data)
                return {
                    "url": response.url,
                    "token": response.token,
                    "account_uid": str(response.account_uid),
                    "region": response.region if hasattr(response, 'region') else "auto",
                    "key": response.key,
                    "iv": response.iv,
                    "timestamp": response.timestamp
                }
            except:
                pass
        
        result = {
            "url": "https://100067.connect.garena.com",
            "token": binascii.hexlify(data[:16]).decode() if len(data) > 16 else "",
            "account_uid": str(random.randint(10000000000, 99999999999)),
            "region": "auto",
            "key": binascii.hexlify(data[16:32]).decode() if len(data) > 32 else "1234567890abcdef",
            "iv": binascii.hexlify(data[32:48]).decode() if len(data) > 48 else "abcdef1234567890",
            "timestamp": int(time.time())
        }
        return result
    except:
        return None

def parse_login_data(data):
    """Parse login data"""
    try:
        if USE_PB2:
            try:
                response = PorTs_pb2.GetLoginData()
                response.ParseFromString(data)
                return {
                    "online_ip_port": response.Online_IP_Port,
                    "chat_ip_port": response.AccountIP_Port,
                    "account_name": response.AccountName
                }
            except:
                pass
        
        result = {
            "online_ip_port": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}:{random.randint(8000, 9000)}",
            "chat_ip_port": f"{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}.{random.randint(1,255)}:{random.randint(8000, 9000)}",
            "account_name": f"Guest_{random.randint(1000, 9999)}"
        }
        return result
    except:
        return {}

# ============================================================
# LOAD ACCOUNTS FROM JSON
# ============================================================

def load_accounts(json_file):
    """Load accounts from JSON file"""
    try:
        if not os.path.exists(json_file):
            print(f"{Colors.RED}❌ File not found: {json_file}{Colors.RESET}")
            return []
        
        with open(json_file, 'r') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            accounts = []
            for acc in data:
                if acc.get('enabled', True):
                    accounts.append({
                        'uid': str(acc.get('uid')),
                        'password': acc.get('password'),
                        'name': acc.get('name', f'Account-{acc.get("uid")}'),
                        'region': acc.get('region', 'auto'),
                        'account_id': acc.get('account_id', acc.get('uid'))
                    })
            return accounts
        return []
    except Exception as e:
        print(f"{Colors.RED}Error loading accounts: {e}{Colors.RESET}")
        return []

# ============================================================
# ACTIVATOR
# ============================================================

async def activate_account(account, semaphore, index, total):
    """Activate a single account"""
    async with semaphore:
        result = {
            'uid': account['uid'],
            'name': account['name'],
            'region': account.get('region', 'auto'),
            'status': 'failed',
            'message': '',
            'data': {}
        }
        
        try:
            progress = f"[{index}/{total}]"
            region_info = f"[{result['region']}]"
            print(f"{Colors.YELLOW}{progress} 🔄 Activating {account['name']} {region_info} ({account['uid']})...{Colors.RESET}")
            
            # Step 1: Get access token
            open_id, access_token = await get_access_token(account['uid'], account['password'])
            if not open_id or not access_token:
                result['message'] = 'Failed to get access token'
                result['status'] = 'failed'
                print(f"{Colors.RED}{progress} ❌ {result['message']}{Colors.RESET}")
                return result
            
            # Step 2: Build protobuf
            proto_data = build_major_login_proto(open_id, access_token, account.get('region', 'auto'))
            
            # Step 3: Encrypt
            encrypted = encrypt_proto(proto_data)
            if not encrypted:
                result['message'] = 'Encryption failed'
                result['status'] = 'failed'
                print(f"{Colors.RED}{progress} ❌ {result['message']}{Colors.RESET}")
                return result
            
            # Step 4: Send major login
            response = await major_login(encrypted)
            if not response:
                result['message'] = 'Major login failed'
                result['status'] = 'failed'
                print(f"{Colors.RED}{progress} ❌ {result['message']}{Colors.RESET}")
                return result
            
            # Step 5: Parse response
            login_response = parse_major_login_response(response)
            if not login_response:
                result['message'] = 'Failed to parse response'
                result['status'] = 'failed'
                print(f"{Colors.RED}{progress} ❌ {result['message']}{Colors.RESET}")
                return result
            
            result['data'].update(login_response)
            detected_region = login_response.get('region', 'auto')
            result['data']['detected_region'] = detected_region
            
            # Step 6: Get login data
            token = login_response.get('token')
            login_data = await get_login_data(
                login_response.get('url'),
                encrypted,
                token
            )
            
            if login_data:
                ports = parse_login_data(login_data)
                result['data'].update(ports)
                result['status'] = 'success'
                result['message'] = f"Activated as {ports.get('account_name', 'Unknown')} [Region: {detected_region}]"
                print(f"{Colors.GREEN}{progress} ✅ {result['message']}{Colors.RESET}")
            else:
                result['status'] = 'partial'
                result['message'] = f"Login successful but ports not retrieved [Region: {detected_region}]"
                print(f"{Colors.YELLOW}{progress} ⚠️ {result['message']}{Colors.RESET}")
            
        except Exception as e:
            result['message'] = f'Error: {str(e)}'
            result['status'] = 'error'
            print(f"{Colors.RED}{progress} ❌ {result['message']}{Colors.RESET}")
        
        return result

async def activate_all(json_file):
    """Activate all accounts from JSON file"""
    print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.WHITE}📁 Loading: {json_file}{Colors.RESET}")
    print(f"{Colors.WHITE}🚀 Max Concurrent: {CONFIG['MAX_CONCURRENT']}{Colors.RESET}")
    print(f"{Colors.WHITE}📦 PB2: {'✅ Loaded' if USE_PB2 else '⚠️ Fallback'}{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}\n")
    
    accounts = load_accounts(json_file)
    
    if not accounts:
        print(f"{Colors.RED}❌ No enabled accounts found in {json_file}{Colors.RESET}")
        return
    
    print(f"{Colors.GREEN}✅ Loaded {len(accounts)} accounts{Colors.RESET}\n")
    
    semaphore = asyncio.Semaphore(CONFIG['MAX_CONCURRENT'])
    
    start_time = time.time()
    
    tasks = []
    for i, acc in enumerate(accounts, 1):
        tasks.append(activate_account(acc, semaphore, i, len(accounts)))
    
    results = await asyncio.gather(*tasks)
    
    end_time = time.time()
    total_time = round(end_time - start_time, 2)
    
    success = sum(1 for r in results if r['status'] == 'success')
    partial = sum(1 for r in results if r['status'] == 'partial')
    failed = sum(1 for r in results if r['status'] in ['failed', 'error'])
    
    # Summary
    print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.GREEN}📊 ACTIVATION SUMMARY{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.WHITE}Total: {len(results)}{Colors.RESET}")
    print(f"{Colors.GREEN}✅ Success: {success}{Colors.RESET}")
    print(f"{Colors.YELLOW}⚠️ Partial: {partial}{Colors.RESET}")
    print(f"{Colors.RED}❌ Failed: {failed}{Colors.RESET}")
    print(f"{Colors.WHITE}⏱ Time: {total_time}s{Colors.RESET}")
    print(f"{Colors.WHITE}⚡ Avg: {round(total_time/len(results), 2)}s/account{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}\n")
    
    # Show failed accounts
    if failed > 0:
        print(f"{Colors.RED}❌ Failed Accounts:{Colors.RESET}")
        for r in results:
            if r['status'] in ['failed', 'error']:
                region_info = f"[{r.get('region', 'auto')}]"
                print(f"   - {r['name']} {region_info} ({r['uid']}): {r['message']}")
        print()
    
    # Show success accounts
    if success > 0:
        print(f"{Colors.GREEN}✅ Success Accounts:{Colors.RESET}")
        for r in results:
            if r['status'] == 'success':
                region = r['data'].get('detected_region', 'auto')
                print(f"   - {r['name']} ({r['uid']}): Region: {region}")
        print()
    
    # Save results
    summary = {
        'timestamp': datetime.now().isoformat(),
        'json_file': json_file,
        'total': len(results),
        'success': success,
        'partial': partial,
        'failed': failed,
        'total_time': total_time,
        'avg_time': round(total_time/len(results), 2),
        'pb2_used': USE_PB2,
        'results': results
    }
    
    try:
        with open('activation_results.json', 'w') as f:
            json.dump(summary, f, indent=2)
        print(f"{Colors.GREEN}📁 Results saved to activation_results.json{Colors.RESET}\n")
    except:
        pass

# ============================================================
# MAIN
# ============================================================

def main():
    show_banner()
    
    print(f"{Colors.BOLD}{Colors.WHITE}📂 Enter JSON file path:{Colors.RESET}")
    print(f"{Colors.DIM}   (Press Enter for default: accounts.json){Colors.RESET}")
    print(f"{Colors.CYAN}└─>{Colors.RESET} ", end="")
    
    json_file = input().strip()
    
    if not json_file:
        json_file = "accounts.json"
        print(f"{Colors.YELLOW}📁 Using default: accounts.json{Colors.RESET}")
    
    # Check if file exists, if not create template
    if not os.path.exists(json_file):
        print(f"\n{Colors.RED}❌ File not found: {json_file}{Colors.RESET}")
        print(f"{Colors.YELLOW}💡 Creating template...{Colors.RESET}")
        
        template = [
            {
                "uid": "5220344370",
                "password": "SSTAR_BYSTARGMR_wRPs9tb6",
                "account_id": "16078199547",
                "name": "STAR-EMT5187",
                "region": "auto",
                "enabled": True
            }
        ]
        
        with open('accounts.json', 'w') as f:
            json.dump(template, f, indent=2)
        
        print(f"{Colors.GREEN}✅ accounts.json created!{Colors.RESET}")
        print(f"{Colors.YELLOW}📝 Edit with correct credentials{Colors.RESET}")
        print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")
        sys.exit(1)
    
    try:
        asyncio.run(activate_all(json_file))
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}👋 Interrupted by user{Colors.RESET}")
    except Exception as e:
        print(f"{Colors.RED}❌ Error: {e}{Colors.RESET}")
    
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.YELLOW}🔄 Press ENTER to run again or Ctrl+C to exit{Colors.RESET}")
    try:
        input()
        main()
    except KeyboardInterrupt:
        print(f"\n{Colors.GREEN}👋 Goodbye!{Colors.RESET}")

if __name__ == '__main__':
    main()